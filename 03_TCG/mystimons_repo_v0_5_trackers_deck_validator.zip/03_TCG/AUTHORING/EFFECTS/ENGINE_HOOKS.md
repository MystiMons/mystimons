# Engine Hooks — Effect Handler API (v0.5)

This spec makes `digital.app_effect_id` implementable **without interpretation**.
It is designed for a **server-authoritative** engine and a Unity client that renders Events and gathers player input.

## Core invariants

- **Server authoritative:** client sends Commands; server emits Events.
- **Deterministic:** same Command stream → same Event stream.
- **Hidden-info safe:** server can send different payloads to P1/P2 via `audience`, with optional `redacted` fields.

---

## 1) Effect lifecycle

### 1.1 Availability check (server/engine)

Before an activation resolves, the engine must verify:

1. `window` is in `handler_signatures[effect_id].allowed_windows`.
2. **Cap check**: if `handler_signatures[effect_id].cap` exists, the referenced tracker must be `< max`.
3. Source exists and is owned/controlled by the player.
4. Any effect-specific preconditions (e.g., “Active exists”, “target exists”).

If any check fails, emit `EFFECT_FAILED` (reason code) and do not mutate state.

### 1.2 Activation flow

1. Client submits `ACTIVATE_EFFECT`.
2. Server emits `EFFECT_ACTIVATED`.
3. If the effect requires a choice:
   - Server emits `CHOICE_PROMPTED` with `audience=P1` and `redacted` payload for `audience=P2` (if required).
   - Client answers with `SUBMIT_CHOICE`.
   - Server emits `CHOICE_RESOLVED`.
4. Server emits `EFFECT_RESOLVED` and applies state changes as part of that resolution.

---

## 2) Standard prompt types

### 2.1 YES_NO
Payload:
- prompt: `{ prompt_type: "YES_NO", message: string }`
- choice: `{ yes: boolean }`

### 2.2 SELECT_TARGET_BENCH
Payload:
- prompt: `{ prompt_type: "SELECT_TARGET_BENCH", allowed_slots: ["BENCH_1","BENCH_2"], message: string }`
- choice: `{ slot: "BENCH_1" | "BENCH_2" }`

### 2.3 SELECT_CARD_FROM_REVEAL (hidden-info)
Used for “reveal top N cards to yourself, pick one”.

Server responsibilities:
- Emit `CHOICE_PROMPTED` twice:
  - `audience=P1`: includes full revealed cards (ids + metadata references).
  - `audience=P2`: includes only `{ reveal_count: N }` (no card identities).

Choice:
- Client returns `{ selected_index: 0..N-1 }`.
- Server resolves by applying the selected card to the player’s hand and rearranging the remainder (policy-defined).

---

## 3) Command contract (minimal)

### 3.1 ACTIVATE_EFFECT
```
{
  "type": "ACTIVATE_EFFECT",
  "match_id": "...",
  "player_id": "P1",
  "seq": 123,
  "window": "TURN.MAIN",
  "payload": {
    "effect_id": "EFF_MINI_SEARCH_001",
    "source_card_instance_id": "CI_...",
    "targets": { }
  }
}
```

### 3.2 SUBMIT_CHOICE
```
{
  "type": "SUBMIT_CHOICE",
  "match_id": "...",
  "player_id": "P1",
  "seq": 124,
  "window": "TURN.MAIN",
  "payload": {
    "prompt_id": "PR_...",
    "choice": { "selected_index": 1 }
  }
}
```

---

## 4) Event contract (minimal)

### 4.1 EFFECT_ACTIVATED / EFFECT_RESOLVED
- Must include `effect_id` and `source_card_instance_id`.
- If the effect consumes a cap, it must be reflected either as:
  - a tracker mutation event, or
  - a clear note in `EFFECT_RESOLVED.payload.tracker_deltas`.

### 4.2 CHOICE_PROMPTED (hidden-info safe)
- Event emitted with `audience`:
  - `audience=P1` includes full prompt payload.
  - `audience=P2` includes a redacted payload.

### 4.3 EFFECT_FAILED
- Includes `reason_code` (e.g., `WINDOW_INVALID`, `CAP_EXCEEDED`, `SOURCE_INVALID`, `PRECONDITION_FAILED`).

---

## 5) Tracker caps and resets (v0.5)

- Cap trackers are defined in `03_TCG/AUTHORING/MATCH/trackers.json`.
- All `scope=PLAYER_TURN` trackers reset at `TURN.START`.
- For mini-effects, the canonical caps are:

| Effect | Tracker | Max | Reset |
|---|---|---:|---|
| Draw | `cap_draw_used_this_turn` | 1 | `TURN.START` |
| Heal | `cap_heal_used_this_turn` | 1 | `TURN.START` |
| Search | `cap_search_used_this_turn` | 1 | `TURN.START` |
| Relic discount | `cap_relic_discount_used_this_turn` | 1 | `TURN.START` |

---

## 6) Suggested C# interfaces (non-binding)

```csharp
public interface IEffectHandler
{
    string EffectId { get; }
    bool IsAvailable(GameState state, EffectContext ctx, out string reasonCode);
    EffectResolution Activate(GameState state, EffectContext ctx); // may return Prompt
    EffectResolution ResolveChoice(GameState state, EffectContext ctx, PlayerChoice choice);
}

public record EffectContext(
    string MatchId,
    string PlayerId,
    string WindowId,
    string SourceCardInstanceId,
    IReadOnlyDictionary<string, object> Targets,
    IRandomSource Rng
);

public record EffectResolution(
    IReadOnlyList<MatchEvent> Events,
    Prompt? Prompt
);
```

The authoritative implementation lives server-side; the Unity client can mirror this purely for preview/UX, never for authority.
