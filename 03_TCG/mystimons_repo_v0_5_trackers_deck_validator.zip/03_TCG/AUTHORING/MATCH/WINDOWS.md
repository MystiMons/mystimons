# Match Windows (v0.5)

Canonical `window` IDs for Command validation and Smart-Mat lock integration.

## Windows

| Window ID | Phase | Smart Mat Lock | Purpose |
|---|---|---|---|
| `SETUP.MULLIGAN` | SETUP | CHARGE | Initial hand validation and mulligan resolution. |
| `SETUP.SELECT_ACTIVE` | SETUP | CHARGE | Place/select Active and Bench. |
| `TURN.START` | TURN_START | AFTERGLOW | Server advances turn, resets per-turn trackers. |
| `TURN.DRAW` | DRAW | CHARGE | Draw step (server emits draw event; client may ack). |
| `TURN.ENERGY` | ENERGY | CHARGE | Energy attachment step (if enabled by mode). |
| `TURN.MAIN` | MAIN | CHARGE | Play cards, activate abilities/effects. |
| `TURN.COMBAT.DECLARE` | COMBAT | CHARGE | Declare attacks/targets. |
| `TURN.COMBAT.RESOLVE` | COMBAT | CLASH | Resolve damage/effects. Zone changes illegal unless effect-granted. |
| `TURN.END` | END | AFTERGLOW | Cleanup. Expire statuses. Advance to next turn. |

## Tracker Reset Policy

- All trackers with `scope=PLAYER_TURN` reset at `TURN.START`.
- Status trackers expire at `TURN.END` if their duration is `UNTIL_TURN_END`.
- Zone locks are enforced during `TURN.COMBAT.RESOLVE` (CLASH) by both app and engine.
