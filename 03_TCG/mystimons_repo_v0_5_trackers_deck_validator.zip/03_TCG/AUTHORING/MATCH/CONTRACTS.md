# Match Contracts (v0.5)

This document is the canonical reference for Match Commands/Events.

## 1) Command rules

- Commands are submitted in strict sequence by each player (`seq`).
- Server validates:
  - `seq` monotonic per player
  - `window` matches current authoritative match window
  - payload validity + ownership
- Invalid commands are rejected via `EFFECT_FAILED` (or a future `COMMAND_REJECTED`) and do not mutate state.

## 2) Minimal Command vocabulary

| Type | Intended window(s) | Notes |
|---|---|---|
| `DRAW_ACK` | `TURN.DRAW` | Optional, for UX sync only. |
| `PLAY_CARD` | `TURN.MAIN` | For Actions/Relics/Terrain/Energy and summons. |
| `DECLARE_ATTACK` | `TURN.COMBAT.DECLARE` | Declares attacker + target. |
| `END_TURN` | `TURN.END` | Player indicates end; server advances. |
| `ACTIVATE_EFFECT` | `TURN.MAIN` | Activates `digital.app_effect_id`. |
| `SUBMIT_CHOICE` | `TURN.MAIN` | Completes a `CHOICE_PROMPTED`. |
| `CONCEDE` | any | Immediate match end. |

## 3) Minimal Event vocabulary

| Type | Audience | Notes |
|---|---|---|
| `MATCH_STARTED` | ALL | Includes initial config/seed commit. |
| `TURN_STARTED` | ALL | Includes active player and resets. |
| `CARD_DRAWN` | P1/P2 | Audience-scoped (only controller sees exact card id). |
| `CARD_PLAYED` | ALL | Public information. |
| `ATTACK_DECLARED` | ALL | Public information. |
| `DAMAGE_APPLIED` | ALL | Public information. |
| `CHOICE_PROMPTED` | P1/P2 | P1 gets full prompt; P2 gets redacted. |
| `CHOICE_RESOLVED` | ALL | Publishes that a choice occurred (details may be minimal). |
| `EFFECT_ACTIVATED` | ALL | Public that effect was activated. |
| `EFFECT_RESOLVED` | ALL | Includes outcome; hidden parts redacted. |
| `EFFECT_FAILED` | P1 | Only the acting player needs full reason. |
| `TURN_ENDED` | ALL | End-of-turn bookkeeping. |
| `MATCH_ENDED` | ALL | Winner/termination reason. |

## 4) Tracker policy (v0.5)

- Per-turn cap trackers reset at `TURN.START`.
- See: `trackers.json` and `TRACKERS.md`.
