# @OBJ-###: [NAME]
**Status:** TBD | Draft | Canon

## Was ist es?
- 

## In-Lore-Funktion
- 

## Merch/Design
- 

## TCG / App Touchpoints
- 
