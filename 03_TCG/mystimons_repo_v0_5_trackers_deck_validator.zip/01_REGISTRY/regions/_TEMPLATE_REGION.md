# @REG-###: [NAME]
**Status:** TBD | Draft | Canon
**Element:** @ELM-###  

## Pitch (2 Sätze)
- 

## Visuelle Marker
- 

## Kultur/Soziales
- 

## Story Hooks
- 

## TCG-Implikationen
- 
