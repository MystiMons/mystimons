| id | name | card_type | rarity | cost | stats | print_text | app_effect_id | tags | notes |
|---|---|---|---|---:|---|---|---|---|---|
| CARD-SET-001-001 | Embrix | MystiMon | Common | 0 | 40/4/2/S1 | — |  | element:Feuer, stage:1 | SPD=3 \| Kleiner Feuersalamander, flackert nervös |
| CARD-SET-001-002 | Aquor | MystiMon | Common | 0 | 45/3/3/S1 | — |  | element:Wasser, stage:1 | SPD=4 \| Leuchtender Otter mit Wasserschwanz |
| CARD-SET-001-003 | Sylphira | MystiMon | Common | 0 | 42/3/3/S1 | — |  | element:Natur, stage:1 | SPD=4 \| Kleiner Waldgeist, Moos und Blüten |
| CARD-SET-001-004 | Terragus | MystiMon | Common | 0 | 50/4/4/S1 | — |  | element:Erde, stage:1 | SPD=2 \| Steinwesen mit Moos-Haar |
| CARD-SET-001-005 | Aeris | MystiMon | Common | 0 | 38/3/2/S1 | — |  | element:Wind, stage:1 | SPD=5 \| Kleiner Wind-Vogel, Kolibri-Energie |
| CARD-SET-001-006 | Frostix | MystiMon | Common | 0 | 44/3/3/S1 | — |  | element:Eis, stage:1 | SPD=4 \| Kleines Eis-Wesen, kristallin |
| CARD-SET-001-007 | Voltis | MystiMon | Common | 0 | 36/4/2/S1 | — |  | element:Blitz, stage:1 | SPD=5 \| Kleines elektrisches Wesen |
| CARD-SET-001-008 | Shadowstrike | MystiMon | Common | 0 | 40/4/2/S1 | — |  | element:Schatten, stage:1 | SPD=4 \| Kleines Schatten-Wesen, formlos |
| CARD-SET-001-009 | Lumix | MystiMon | Common | 0 | 42/3/3/S1 | — |  | element:Licht, stage:1 | SPD=4 \| Kleines Licht-Wesen, Fee-artig |
| CARD-SET-001-010 | Ironix | MystiMon | Common | 0 | 48/4/4/S1 | — |  | element:Metall, stage:1 | SPD=2 \| Kleiner Metall-Golem |
| CARD-SET-001-011 | Drakyn | MystiMon | Common | 0 | 46/4/3/S1 | — |  | element:Drache, stage:1 | SPD=4 \| Baby-Drache, alle Elemente subtil |
| CARD-SET-001-012 | Mossling | MystiMon | Common | 0 | 10/0/0/S1 | — | EFF_MINI_DRAW_001 | element:Natur, stage:1, role:draw-support | Winziger Moosklumpen mit Augen; Neugierig, folgt Menschen \| MVP-role: Draw-Support |
| CARD-SET-001-013 | Bublin | MystiMon | Common | 0 | 10/0/0/S1 | — | EFF_MINI_HEAL_001 | element:Wasser, stage:1, role:heal-support | Schwebende Wasserblase; Verspielt, platzt bei Gefahr \| MVP-role: Heal-Support |
| CARD-SET-001-014 | Flickerling | MystiMon | Common | 0 | 10/0/0/S1 | — | EFF_MINI_BURN_001 | element:Feuer, stage:1, role:burn-enabler | Tanzende kleine Flamme; Rastlos, flackert \| MVP-role: Burn-Enabler |
| CARD-SET-001-015 | Peblit | MystiMon | Common | 0 | 10/0/0/S1 | — | EFF_MINI_DEF_001 | element:Erde, stage:1, role:def-buff | Rollender Kieselstein mit Gesicht; Stur, bleibt stehen \| MVP-role: DEF-Buff |
| CARD-SET-001-016 | Breezel | MystiMon | Common | 0 | 10/0/0/S1 | — | EFF_MINI_SPD_001 | element:Wind, stage:1, role:spd-buff | Unsichtbarer Windwirbel; Schnell, neckisch \| MVP-role: SPD-Buff |
| CARD-SET-001-017 | Shardling | MystiMon | Common | 0 | 10/0/0/S1 | — | EFF_MINI_FREEZE_001 | element:Eis, stage:1, role:freeze-support | Schwebender Eissplitter; Still, kalt \| MVP-role: Freeze-Support |
| CARD-SET-001-018 | Sparklin | MystiMon | Common | 0 | 10/0/0/S1 | — | EFF_MINI_PARALYZE_001 | element:Blitz, stage:1, role:paralyze-support | Knisternder Funkenball; Hyperaktiv, zappelig \| MVP-role: Paralyze-Support |
| CARD-SET-001-019 | Gloomlet | MystiMon | Common | 0 | 10/0/0/S1 | — | EFF_MINI_STEALTH_001 | element:Schatten, stage:1, role:stealth-enabler | Schatten, der sich bewegt; Scheu, versteckt sich \| MVP-role: Stealth-Enabler |
| CARD-SET-001-020 | Glimmer | MystiMon | Common | 0 | 10/0/0/S1 | — | EFF_MINI_SEARCH_001 | element:Licht, stage:1, role:search-support | Leuchtender Lichtpunkt; Freundlich, führt \| MVP-role: Search-Support |
| CARD-SET-001-021 | Coglet | MystiMon | Common | 0 | 10/0/0/S1 | — | EFF_MINI_RELIC_001 | element:Metall, stage:1, role:relic-support | Winziges Zahnrad-Wesen; Mechanisch, tickt \| MVP-role: Relic-Support |
| CARD-SET-001-022 | Moosveil | MystiMon | Rare | 0 | 78/6/6/S3 | — |  | element:Natur, stage:3 | SPD=4 \| Theos Partner; seltener Waldwächter. (Stats/Effect: Placeholder für v0.3) |