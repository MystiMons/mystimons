# SET-001 — Overview
**Status:** Draft
**Scope:** Basisset (22 Kreaturen) — basierend auf Buch 1

## Design Goals
- 
## Keyword Pool
- 
## Draft/Sealed (falls relevant)
- 
## Print vs Digital
- Siehe: /03_TCG/PRINT_VS_DIGITAL.md
