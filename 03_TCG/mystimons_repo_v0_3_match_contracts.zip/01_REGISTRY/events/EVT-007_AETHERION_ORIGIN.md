# EVT-007 — Aetherion Origin (Band 7)

**ID:** EVT-007  
**Type:** Canon Event (Prequel / Origin)  
**Status:** LOCKED-UNTIL-BOOK-7 (Spoiler Gate)  

## Kurzbeschreibung
Die Entstehung von **Aetherion** (Origin/Prequel). Vollständige Fakten werden erst in **Band 7** erzählt.

## Constraints
- Muss PRIORITY 0–2 respektieren (keine Retcons gegen Canon Laws / Magiesystem).
- Vor Band 7 dürfen nur Myth/Fragment-Referenzen existieren (ARC-SPOIL-002).

## Links
- @LAW-008 (Aetherion bleibt Mysterium)
- @ARC-ORIGIN-001 (Band 7 = Origin/Prequel)

## Notes (TBD)
- Ort/Zeit: TBD
- Catalyst: TBD
- Preis/Kosten: TBD
