# @CRE-###: [NAME]
**Status:** TBD | Draft | Canon
**Element:** @ELM-###  
**Archetype:**  

## Persönlichkeit (3 Stichpunkte)
- 

## Lore-Funktion
- 

## TCG-Design-Notizen
- Print-Kern:
- Digital-Add-on:
- Exploit-Risiko:
