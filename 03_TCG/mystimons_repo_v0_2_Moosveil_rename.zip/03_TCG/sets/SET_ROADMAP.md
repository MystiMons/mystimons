# TCG SET ROADMAP (Scaffold)

This folder contains set scaffolds aligned to Books 1–7.

## Sets
- SET-001 (Book 1) — existing
- SET-002 (Book 2) — scaffold
- SET-003 (Book 3) — scaffold
- SET-004 (Book 4) — scaffold
- SET-005 (Book 5) — scaffold
- SET-006 (Book 6) — scaffold
- SET-007 (Book 7 / Origin) — scaffold + Origin Frame

See also: `REVEAL_LEVELS.md`.
