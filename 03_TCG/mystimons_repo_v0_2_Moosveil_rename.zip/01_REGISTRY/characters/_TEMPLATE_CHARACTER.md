# @CHR-###: [NAME]
**Status:** TBD | Draft | Canon
**Alter:**  
**Region:** @REG-###  
**Fraktion:** @FAC-### (optional)

## Kurzprofil
- 

## Arc (Buch)
- 

## TCG-Relevanz
- 
