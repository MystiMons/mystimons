# @CHR-001: Finn Alder
**Status:** Canon  
**Rolle:** Protagonist (Band 1–3)  
**State (Lore):** Alive (Band 1–3), **Dead (Band 4)**

## Kurzprofil
- Primärer POV / Ankerfigur der Finn-Ära.

## Arc (Buch)
- Band 1–3: Protagonist.
- Band 4: Stirbt (permanent, Lore-Tod). Übergabe an Kira.

## Canon Constraints
- Lore-Tod ist irreversibel (siehe `00_CANON/SINGLE_SOURCE_OF_TRUTH.md`).
- Keine „Resurrection“-Semantik in TCG/App (TCG nutzt KO/Rebind).

## Referenzen
- Event: @EVT-004 (Finns Tod)
