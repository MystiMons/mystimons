# @ELM-###: [NAME]
**Status:** TBD | Draft | Canon
**Region:** @REG-###  
**Farbe:** #RRGGBB  
**Philosophie (1 Satz):**  

## Kernfantasie
- 

## Stärken/Schwächen (Lore)
- Stärken:  
- Schwächen:  

## TCG-Identität (High Level)
- Archetypes:  
- Do/Don't:  

## Verknüpfungen
- Region: @REG-###
- Fraktionen (optional): @FAC-###
