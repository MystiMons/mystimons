# Book 02 – Character Arcs (WIP)

## Finn (CHR-FINN)
- 

## Supporting
- 
