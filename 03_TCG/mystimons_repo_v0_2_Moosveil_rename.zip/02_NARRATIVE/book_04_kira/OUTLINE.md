# Book 04 (Kira) – Outline (WIP)

- Protagonist: Kira
- Canon: Follow 00_CANON/SINGLE_SOURCE_OF_TRUTH.md

## Act Structure
- Act I:
- Act II:
- Act III:

## Key Events
- 


## Key Event
- @EVT-004: Finn’s death triggers protagonist handoff.
