# Kapitel 1: Der Klang

## TEST-KAPITEL (Workflow-Test)

*Dieses Kapitel dient nur zum Testen des narrative-review Workflows.*

---

Finn wachte auf. Die Stimmen waren wieder da.

Nicht Worte – Gefühle. Hunderte gleichzeitig. Grün wie Moos, rot wie Alarm, blau wie Trauer. Sie drückten gegen seine Schläfen wie zu tiefes Tauchen.

„Zu laut", flüsterte er. „Zu viele."

Seine Finger fanden das Armband an seinem Handgelenk. Geflochtenes Leder, abgenutzt. Theos Hände hatten das gemacht. Vor zwei Jahren. Bevor er verschwand.

Finn schloss die Augen und atmete. Vier Sekunden ein. Vier halten. Vier aus. Wie Mutter es ihm beigebracht hatte.

Die Stimmen wurden leiser. Nie weg. Aber leiser.

Von unten rief Mutter: „Finn! Das Fest beginnt bald!"

Sein Magen verkrampfte sich.

Das Fest. Die Zeremonie. Wieder.

---

**[ENDE TEST-KAPITEL]**
# Kapitel 1: Test

Finn wachte auf. Die Stimmen waren wieder da.

Das ist ein Test-Kapitel für den Workflow.
# Test
