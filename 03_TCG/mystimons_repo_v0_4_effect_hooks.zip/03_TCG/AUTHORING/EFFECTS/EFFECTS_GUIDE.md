# Effects Registry (v0.2)

This directory defines **digital app effects** referenced by `digital.app_effect_id` on cards.

## Principles
- Effects are **deterministic** unless explicitly marked otherwise.
- Effects operate on **Commands → Events**; clients never compute rule outcomes.
- Hidden information is represented as server-side selections; clients receive only what is allowed by reveal policy.

## Mini-Resonant Baseline
Mini-Resonants in SET-001 use small, testable effects (draw/heal/search etc.).
To prevent exploit loops, several effects rely on **per-turn caps** tracked via `digital.tracking`.

## Effect IDs in SET-001
- `EFF_MINI_DRAW_001` — Mossling — Draw Support (activated, OncePerTurn_MainPhase)
- `EFF_MINI_HEAL_001` — Bublin — Heal Support (activated, OncePerTurn_EndPhase)
- `EFF_MINI_BURN_001` — Flickerling — Burn Enabler (triggered, OnAttackDeclared)
- `EFF_MINI_DEF_001` — Peblit — DEF Buff (passive, WhileInPlay)
- `EFF_MINI_SPD_001` — Breezel — SPD Buff (passive, WhileInPlay)
- `EFF_MINI_FREEZE_001` — Shardling — Freeze Support (triggered, OnDamageDealt)
- `EFF_MINI_PARALYZE_001` — Sparklin — Paralyze Support (triggered, OnTurnStart)
- `EFF_MINI_STEALTH_001` — Gloomlet — Stealth Enabler (activated, OncePerTurn_MainPhase)
- `EFF_MINI_SEARCH_001` — Glimmer — Search Support (activated, OncePerTurn_MainPhase)
- `EFF_MINI_RELIC_001` — Coglet — Relic Support (passive, WhileInPlay)

## Engine hooks
See `ENGINE_HOOKS.md` for canonical handler signatures, prompt contracts, and the mapping from effect IDs to commands/events.

