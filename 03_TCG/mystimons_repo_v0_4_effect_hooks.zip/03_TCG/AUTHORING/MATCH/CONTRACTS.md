# Match Contracts v0.4 (Minimal Set)

This file defines the minimal **Command/Event** vocabulary required to implement an authoritative match runtime *including* `digital.app_effect_id`.

## Commands

| Command Type | Allowed Windows | Modes | Payload Shape (high-level) |
|---|---|---|---|
| `SETUP_SELECT_ACTIVE` | `SETUP.SELECT_ACTIVE` | EINFACH, STANDARD, TURNIER | `{ card_id, source_zone }` |
| `SETUP_ADD_BENCH` | `SETUP.SELECT_BENCH` | EINFACH, STANDARD, TURNIER | `{ card_id, bench_slot }` |
| `SETUP_MULLIGAN` | `SETUP.MULLIGAN` | EINFACH, STANDARD, TURNIER | `{ confirm: true }` |
| `SETUP_READY` | `SETUP.READY` | EINFACH, STANDARD, TURNIER | `{ confirm: true }` |
| `DRAW_ACK` | `TURN.DRAW` | EINFACH, STANDARD, TURNIER | `{ confirm: true }` |
| `ATTACH_ENERGY` | `TURN.ENERGY` | EINFACH, STANDARD, TURNIER | `{ energy_card_id, dest: 'ATTACHED'|'POOL', target_instance_id? }` |
| `SUMMON_STAGE1` | `TURN.MAIN` | EINFACH, STANDARD, TURNIER | `{ card_id, dest: 'ACTIVE'|'BENCH', bench_slot? }` |
| `EVOLVE` | `TURN.MAIN` | STANDARD, TURNIER | `{ base_instance_id, evo_card_id }` |
| `RITUAL_SUMMON` | `TURN.MAIN` | TURNIER | `{ champion_card_id, sacrifices: [instance_id...] }` |
| `PLAY_ITEM` | `TURN.MAIN` | EINFACH, STANDARD, TURNIER | `{ card_id, targets? }` |
| `PLAY_RELIC` | `TURN.MAIN` | STANDARD, TURNIER | `{ card_id }` |
| `PLAY_TERRAIN` | `TURN.MAIN` | STANDARD, TURNIER | `{ card_id }` |
| `SWITCH` | `TURN.MAIN` | EINFACH, STANDARD, TURNIER | `{ from_instance_id, to_instance_id }` |
| `ATTACK` | `TURN.COMBAT.DECLARE` | EINFACH, STANDARD, TURNIER | `{ attacker_instance_id, attack_id, target_instance_id? }` |
| `ACTIVATE_EFFECT` | `TURN.MAIN`, `TURN.END` (per effect) | EINFACH, STANDARD, TURNIER | `{ intent_id, source_instance_id, effect_id }` |
| `SUBMIT_CHOICE` | *server-defined prompt windows* | EINFACH, STANDARD, TURNIER | `{ prompt_id, selections }` |
| `END_TURN` | `TURN.END` | EINFACH, STANDARD, TURNIER | `{ confirm: true }` |
| `SURRENDER` | `ANY` | EINFACH, STANDARD, TURNIER | `{ confirm: true }` |

## Events

| Event Type | Audience | Payload Shape (high-level) |
|---|---|---|
| `MATCH_CREATED` | ALL | `{ match_id, players, mode, seed_commit? }` |
| `MATCH_STARTED` | ALL | `{ starting_player_id }` |
| `SETUP_REQUIRED` | P1|P2 | `{ step: 'SELECT_ACTIVE'|'SELECT_BENCH'|'MULLIGAN'|'READY' }` |
| `CARD_DRAWN` | P1|P2 | `{ player_id, count, cards?: [{instance_id, card_id}] }` (opponent redacted) |
| `ENERGY_ATTACHED` | ALL | `{ player_id, energy_card_id, target_instance_id }` |
| `ENERGY_POOLED` | ALL | `{ player_id, energy_card_id }` |
| `CARD_SUMMONED` | ALL | `{ player_id, instance_id, card_id, dest }` |
| `CARD_EVOLVED` | ALL | `{ player_id, base_instance_id, evo_instance_id, evo_card_id }` |
| `CARD_PLAYED_ITEM` | ALL | `{ player_id, item_card_id, targets? }` |
| `CARD_PLAYED_RELIC` | ALL | `{ player_id, relic_card_id }` |
| `TERRAIN_CHANGED` | ALL | `{ player_id, terrain_card_id }` |
| `SWITCHED` | ALL | `{ player_id, from_instance_id, to_instance_id }` |
| `ATTACK_DECLARED` | ALL | `{ player_id, attacker_instance_id, attack_id, target_instance_id? }` |
| `DAMAGE_APPLIED` | ALL | `{ source_instance_id?, target_instance_id, amount }` |
| `STATUS_APPLIED` | ALL | `{ target_instance_id, status_id, duration? }` |
| `KO` | ALL | `{ target_instance_id }` |
| `HAND_DISCARD` | P1|P2 | `{ player_id, discarded: [{instance_id, card_id}] }` |
| `CHOICE_PROMPTED` | P1 or P2 | `{ prompt_id, prompt_type, constraints, choices? }` (opponent redacted) |
| `CHOICE_RESOLVED` | P1 or P2 | `{ prompt_id, selection }` (redaction allowed) |
| `EFFECT_ACTIVATED` | ALL | `{ intent_id, source_instance_id, effect_id }` |
| `EFFECT_RESOLVED` | ALL | `{ intent_id, effect_id }` (+ domain events) |
| `EFFECT_FAILED` | P1 or P2 | `{ intent_id?, effect_id?, reason_code, message }` |
| `TURN_ENDED` | ALL | `{ player_id, next_player_id, turn_number }` |
| `MATCH_ENDED` | ALL | `{ winner_player_id, reason }` |
| `COMMAND_REJECTED` | P1 or P2 | `{ cmd_id, reason_code, message }` |
| `STATE_SNAPSHOT` | P1|P2 | `{ state }` (debug/reconcile) |

### Audience/Redaction
- Server may emit **different payloads** per audience (e.g., opponent receives redacted `card_id` for draws/search).
- Persisted match logs (for arbitration/debug) should store the **full** payload, then derive client streams via redaction.

## Window → Smart Mat Mapping
- `CHARGE`: movement allowed (normal play)
- `CLASH`: movement locked (combat resolution)
- `AFTERGLOW`: movement allowed (cleanup/idle)
