# @CHR-011: Kira
**Status:** Canon (Rolle), Details TBD  
**Rolle:** Protagonistin (ab Band 4)

## Kurzprofil
- Übernimmt die narrative Hauptrolle ab Band 4 nach Finns Tod.

## Arc (Buch)
- Band 4+: Protagonistin.
- Band 1–3: Auftritt/Setup TBD (Cameo/Supporting), muss später festgelegt werden.

## Canon Constraints
- Übergabe-Event: Finns Tod ist dauerhaft und darf nicht „unterlaufen“ werden.

## Referenzen
- Event: @EVT-004 (Finns Tod)
