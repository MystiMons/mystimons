# @KWD-###: **[KEYWORD]**
**Status:** TBD | Draft | Canon
**Kategorie:** Core | Combat | Status | Resource | Location | Organization

## Print-Text (Kurz & klar)
- **[Keyword]** — [1 Satz Regeltext]

## Digitale Logik (App)
- Tracking:
- Edge Cases:
- UI:
- Exploit-Risiko:

## Notes
- 
