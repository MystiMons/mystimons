# @FAC-###: [NAME]
**Status:** TBD | Draft | Canon

## Rolle in Aetheria
- 

## Visuelle Sprache
- Farben:
- Formen:
- Iconography:

## Werte & Methoden
- 

## Schlüssel-Charaktere
- @CHR-###

## TCG-Identität
- Playstyle:
- Signature Mechanics (print/digital):
