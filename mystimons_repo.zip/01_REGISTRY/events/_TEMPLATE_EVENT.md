---
id: EVT-###
name: ""
type: ""
book: ""
severity: soft|hard_canon
constraints: []
spoiler_policy: {}
---
# (EVT-###)

## Canon Statement

## Dependencies / Links

## TCG/App Guidance
