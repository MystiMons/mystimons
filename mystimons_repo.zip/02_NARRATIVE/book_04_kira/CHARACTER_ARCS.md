# Book 04 (Kira) – Character Arcs (WIP)

## Kira (CHR-KIRA)
- 

## Finn (CHR-FINN)
- 

## Supporting
- 
