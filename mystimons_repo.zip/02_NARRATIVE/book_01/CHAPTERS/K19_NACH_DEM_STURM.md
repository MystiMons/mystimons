# KAPITEL 19: NACH DEM STURM

Wind pfeift durch Risse im Holz. Nicht laut. Nicht schreiend. Nur da. Konstantes Zischen, als würde die Stadt selbst ausbluten.

Finn stand auf einem Deck, das sich nach links neigte. Unter ihm: Wolken. Weiß. Endlos. Über ihm: Zerrissene Segel, die wie Fahnen im Wind flatterten. Taue hingen herab, zersplittert, nutzlos.

Die Hände zitterten.

Erst jetzt. Nicht während des Kampfes. Nicht als Calder Theo packte. Jetzt. Wenn alles still war. Wenn die Adrenalin-Welle abflachte und nur noch die Leere blieb.

Seine Finger griffen nach etwas. Nichts. Luft. Wo Theo eben noch gestanden hatte. Wo seine Hand Finns Schulter berührt hatte. "Bleib hier. Ich komme zurück."

Gelogen.

Finns Knie gaben nach. Er stützte sich gegen einen Mast. Splitter bohrten sich in seine Handfläche. Er spürte es nicht.

Der Mast war warm. Noch. Von der Hitze des Kampfes. Von den Flammen, die Calder entfacht hatte. Von Ferron, dem Metall-Titan, der durch die Decks gebrochen war wie durch Papier.

Finns Handfläche klebte. Blut. Sein eigenes? Das von anderen? Er wusste es nicht. Konnte es nicht unterscheiden.

Irgendwo knarrte Holz. Langsam. Wie ein Seufzen. Ein Schiff, das sich verabschiedete.

Ein Geruch. Verbranntes Fleisch. Nicht stark. Aber da. Im Wind. Vermischt mit Rauch und Ruß und etwas anderem. Salz. Tränen.

Finn schluckte. Hart. Die Kehle war trocken. Wie Sandpapier.

Rufe. Irgendwo. Leise. Verloren im Wind.

Er drehte sich um. Langsam. Jede Bewegung kostete Kraft, die er nicht hatte.

Das Deck war übersät mit Trümmern. Holzsplitter. Zerrissene Planen. Ein Eimer, umgekippt, Wasser sickerte durch die Ritzen. Weiter hinten: Menschen. Widerstand. Sie bewegten sich. Reparierten. Verbänden. Arbeiteten.

Als wäre nichts passiert.

Als wäre Theo nicht weg.

Finns Blick wanderte. Über das Deck. Über die Schäden. Ein Riss, der sich durch das Holz zog. Zwei Meter lang. Tief. Als hätte jemand mit einer Axt geschlagen. Ferron. Das musste Ferron gewesen sein.

Ein Stück Tau. Zerrissen. Ein Ende baumelte im Wind. Das andere lag auf dem Deck. Nass. Rot. Nicht von Farbe. Von Blut.

Ein Widerstandskämpfer. Älter. Grauer Bart. Kauerte sich neben einem Verletzten. Bandagierte eine Wunde. Langsam. Vorsichtig. Seine Hände zitterten. Nicht vor Kälte. Vor Erschöpfung.

Der Verletzte stöhnte. Leise. Unterdrückt. Als würde er versuchen, still zu sein. Als würde Lärm mehr Gefahr bedeuten.

Finns Magen zog sich zusammen. Wieder. Stärker diesmal.

Überall. Überall Verletzte. Überall Trümmer. Überall Schaden.

Und Theo war weg.

Nicht tot. Weg. Gefangen. Von Calder. Dem Champion. Dem, der unbesiegbar war.

Finns Finger krallten sich in den Mast. Die Nägel brachen. Er spürte es nicht.

Finns Magen zog sich zusammen. Übelkeit stieg. Er schluckte. Hart. Bitter.

"Finn."

Eine Stimme. Nila. Hinter ihm.

Er drehte sich nicht um. Konnte nicht. Wenn er sich bewegte, würde er zusammenbrechen. Das wusste er. Instinktiv. Wie man weiß, dass eine Wunde blutet, bevor man hinschaut.

"Finn, wir müssen—"

"Lass ihn."

Elara. Ihre Stimme war ruhig. Nicht sanft. Fest.

Schritte. Näher. Dann: Stille.

Finn atmete. Einmal. Zweimal. Die Luft brannte in der Lunge. Ruß. Rauch. Der Geruch von verbranntem Holz und etwas anderem. Metall. Blut.

Er zwang sich, den Kopf zu heben.

Das Team stand vor ihm. Nila, Aquor an ihrer Seite. Der Otter winselte leise. Rex, Embrix auf der Schulter. Der Salamander zuckte. Unruhig. Elara, Terragus neben ihr. Der Steinwesen bewegte sich nicht. Stand. Wie ein Fels.

Rex' Gesicht war anders. Nicht wütend. Nicht laut. Still. Gefährlich still. Seine Hände waren zu Fäusten geballt. Die Knöchel weiß.

Nila war zu ruhig. Das war das Zeichen. Wenn Nila zu ruhig war, rechnete sie. Plante. Analysierte. Das bedeutete: Sie hatte keine Lösung. Noch nicht.

Elara schaute Finn an. Direkt. Nicht mitleidig. Hart. Aber nicht kalt. Dann blickte sie über seine Schulter. Auf die Fluchtwege. Die Ausgänge. Die Möglichkeiten.

Finn öffnete den Mund. Nichts kam raus. Kein Ton. Kein Wort.

Dann, plötzlich:

"Ich hab ihn gefunden."

Die Worte fielen. Wie Steine. Schwer. Hart.

"Und wieder verloren."

Stille.

Nur der Wind. Das Knacken von Holz. Irgendwo ein Seufzen. Ein Widerstandskämpfer, der einen Verletzten stützte.

Rex bewegte sich. Ein Schritt. Zu Finn. Dann stoppte er. Seine Hand hob sich. Fiel wieder.

Nila schaute weg. Auf ihre Hände. Sie rieb sie aneinander. Als würde Dreck darauf kleben.

Elara sagte nichts. Sie setzte sich. Einfach. Direkt auf das Deck. Neben Finn. Nicht zu nah. Nicht zu weit. Genau da, wo sie sein musste.

Finns Beine zitterten. Er ließ sich sinken. Neben Elara. Das Holz war kalt. Nass. Er spürte es durch die Hose. Die Kälte kroch hoch. Langsam. Wie Eis.

"Die Stadt ist kaputt", sagte Rex. Seine Stimme war flach. Keine Frage. Eine Feststellung.

"Die Hälfte der Schiffe", sagte Nila. "Mindestens. Die anderen... sie können fliegen. Aber nicht weit."

"Ressourcen", sagte Elara. "Wasser. Nahrung. Medizin. Alles knapp."

Finn hörte zu. Aber die Worte prallten ab. Wie Regen auf Glas. Sie waren da. Aber sie drangen nicht durch.

Seine Gedanken rasten. Zu schnell. Zu viele. Theo. Calder. Ferron. Die Trümmer. Die Verletzten. Die Schuld.

Alles seine Schuld.

"Die Leute hier", sagte Nila. Ihre Stimme war leiser. Vorsichtiger. "Sie schauen uns an. Anders."

Finn blickte auf. Über das Deck. Zu den Widerstandskämpfern. Sie arbeiteten. Reparierten. Aber ihre Blicke. Immer wieder. Zu ihm. Zu seinem Team.

Nicht wütend. Nicht feindselig.

Vorsichtig. Misstrauisch.

"Paranoia", sagte Elara. Ihre Stimme war ruhig. Analysierend. "Sie fragen sich: Haben WIR das System hierher gebracht."

"Wir haben", sagte Finn.

Die Worte kamen von allein. Laut. Klar. Zu laut. Zu klar.

Die Worte kamen von allein. Laut. Klar.

Alle schauten ihn an.

"Wir haben das System hierher gebracht. Ich. Weil ich Theo gesucht habe. Weil ich hierher gekommen bin."

"Das ist—", begann Rex.

"Wahr", sagte Finn. "Es ist wahr. Alles. Die Trümmer. Die Verletzten. Theo. Alles, weil ich—"

"Stop."

Elara. Ihre Stimme schnitt durch. Nicht schreiend. Ruhig. Fest. Wie ein Urteil.

Finn schaute sie an. Zum ersten Mal richtig. Ihre Augen waren grau. Wie Stein. Aber nicht tot. Lebendig. Brennend.

"Du hast uns durch die Tunnel geführt", sagte sie. "In Terravok. Unter dem Kloster. Du hast die Stimmen gehört. Die blinden Resonanten. Du hast uns rausgeführt."

Finn öffnete den Mund. Schließen.

"Du hast Rex' Vater gefunden", sagte Elara. "In den Minen. Du hast die Resonanten gehört. Die versklavten. Du hast sie befreit. Vier von ihnen. Vier Leben."

"Das war—"

"Du hast UNS zusammengebracht", sagte Elara. Ihre Stimme wurde lauter. Nicht schreiend. Stärker. "Nila. Rex. Mich. Wir waren allein. Jeder für sich. Du hast uns gefunden. Du hast uns gezeigt, dass wir zusammen stärker sind."

Finns Hände zitterten. Er ballte sie zu Fäusten. Die Nägel bohrten sich in die Handflächen. Schmerz. Gut. Konkret.

"Theo ist nicht hier", sagte Elara. "Er ist weg. Gefangen. Das ist wahr."

Sie lehnte sich vor. Näher. Ihre Augen fixierten ihn.

"DU bist hier. Und du bist genug."

Die Worte trafen. Nicht wie ein Schlag. Wie ein Anker. Schwer. Fest. Ziehend.

Finn atmete. Tief. Die Luft brannte. Aber er atmete.

Rex sagte nichts. Aber er blieb. Stand. Wie eine Mauer.

Nila schob etwas hin. Ein Wasserbeutel. Ohne Finn anzusehen. Pragmatisch. Schutz durch Handeln.

Finn nahm ihn. Trank. Das Wasser war warm. Aber es half. Ein bisschen.

Die Kehle brannte weniger. Der Magen beruhigte sich. Ein wenig.

Er atmete. Tief. Einmal. Zweimal.

Die Hände zitterten noch. Aber weniger. Langsam. Sehr langsam.

"Was jetzt?"

Rex. Seine Frage hing in der Luft. Nicht verzweifelt. Praktisch. Logistisch.

Eine Frage, die keine war. Eine Frage, die alles bedeutete.

Nila stand auf. Langsam. Ihre Beine waren steif. Sie streckte sich. Einmal. Dann ging sie. Zu einem umgestürzten Mast. Der lag quer über dem Deck. Zwei Meter lang. Dick. Zersplittert an einem Ende.

Sie kauerte sich hin. Ihre Finger berührten etwas. Vorsichtig. Ein Stück Papier. Zerrissen. Nass. Lag unter dem Mast. Fast unsichtbar.

Sie hob es auf. Drehte es um.

Die Schrift war verwischt. Von Wasser. Von Ruß. Aber lesbar. Gerade so.

"Transport", las sie. Ihre Stimme war flach. Keine Betonung. Nur Fakten. "Nach Lumion. Öffentlich."

Sie hielt inne. Las weiter. Ihre Augen bewegten sich. Schnell. Über das Papier.

"Drei Tage", sagte sie. "Transport startet in drei Tagen. Öffentliche Hinrichtung. Auf dem Platz der Gerechtigkeit."

Finns Herz schlug. Einmal. Hart. Dann wieder. Schneller. Zu schnell. Wie ein Hammer. In seiner Brust.

"Öffentlich", sagte Nila. Ihre Stimme war jetzt lauter. Schärfer. "Das bedeutet—"

"Symbol", sagte Elara. Sie stand auf. Langsam. Ihre Bewegungen waren kontrolliert. Jede Geste durchdacht. "Das System will ein Beispiel. Eine Warnung."

"Eine Hinrichtung", sagte Rex. Seine Stimme war hart. Wie Stein. "Öffentlich. Vor allen. Damit jeder sieht, was passiert, wenn man das System herausfordert."

Finn stand auf. Langsam. Seine Beine trugen ihn. Gerade so. Sie zitterten noch. Aber sie trugen.

"Wann?"

Nila schaute auf das Papier. Ihre Finger zitterten. Leicht. "Drei Tage. Vielleicht vier. Je nachdem, wie schnell der Transport ist."

"Drei Tage", sagte Finn.

Die Worte waren flach. Keine Frage. Eine Feststellung.

Drei Tage.

Drei Tage, um nach Lumion zu kommen.

Drei Tage, um Theo zu finden.

Drei Tage, um ihn zu retten.

Oder drei Tage, um zu spät zu kommen.

Finns Magen zog sich zusammen. Wieder. Aber diesmal war es nicht Übelkeit.

Es war Entschlossenheit.

Die Worte waren flach. Keine Frage. Eine Feststellung.

Er schaute auf seine Hände. Ruß. Blut. Splitter. Die Hände eines Jungen, der zu viel gesehen hatte. Zu viel getan hatte. Zu viel verloren hatte.

Aber sie waren seine Hände.

Er ballte sie zu Fäusten. Öffnete sie wieder. Die Finger gehorchten. Langsam. Aber sie gehorchten.

Die Hände eines Jungen, der kämpfen würde.

"Dann gehen wir nach Lumion."

Stille.

Nicht die Stille der Leere. Die Stille der Entscheidung.

Rex schaute ihn an. Nila schaute ihn an. Elara schaute ihn an.

Alle drei. Gleichzeitig. Als hätten sie es längst gewusst. Als hätten sie nur darauf gewartet, dass er es sagt.

"Wer kommt mit?"

Die Frage war überflüssig. Er wusste die Antwort. Bevor er fragte.

Aber er fragte trotzdem.

Weil es wichtig war. Weil sie die Wahl haben mussten. Weil niemand gezwungen werden sollte, in den Tod zu gehen.

Rex stand auf. Sofort. Keine Pause. Keine Überlegung.

"Du musst nicht fragen."

Nila stand auf. Langsam. Aber fest.

"Lumion ist die Hauptstadt", sagte sie. "Das Herz des Systems. Überall Wachen. Überall Spitzel. Überall Gefahr."

"Ja", sagte Finn.

"Wir werden wahrscheinlich sterben", sagte Nila.

"Wahrscheinlich", sagte Finn.

Nila nickte. Einmal. Kurz.

"Dann gehen wir zusammen."

Elara stand auf. Als letzte. Langsam. Ihre Bewegungen waren bedacht. Jede Geste hatte Gewicht.

Sie schaute Finn an. Direkt. Hart. Aber nicht kalt.

"Lumion ist anders", sagte sie. Ihre Stimme war ruhig. Aber nicht sanft. Wie ein Urteil. "Nicht wie die anderen Regionen. Nicht wie Zephyria. Nicht wie Terravok. Es ist... das System. Rein. Konzentriert. Gefährlich."

"Ich weiß", sagte Finn.

"Du wirst dein Hören brauchen", sagte Elara. "Aber es wird nicht reichen. Lumion ist voll von Resonanten. Unterdrückten. Verängstigten. Die Stimmen werden laut sein. Sehr laut. Vielleicht zu laut. Vielleicht wirst du es nicht aushalten."

"Ich weiß", sagte Finn.

"Du wirst es nicht schaffen", sagte Elara. "Allein."

"Ich bin nicht allein", sagte Finn.

Elara hielt inne. Ihre Augen fixierten ihn. Grau. Wie Stein. Aber lebendig. Brennend.

Dann, langsam, ein Nicken.

"Nein", sagte sie. "Das bist du nicht."

Sie wandte sich um. Zu den Trümmern. Zu den Menschen. Zu der zerstörten Stadt.

Überall arbeiteten sie. Reparierten. Verbänden. Überall Leben. Überall Hoffnung. Trotz allem.

"Der Widerstand kann uns helfen", sagte Elara. "Route. Verkleidung. Transport. Papiere vielleicht. Aber nicht mehr. Sie können nicht mitkommen. Sie können nicht kämpfen. Das müssen wir. Allein."

"Gut", sagte Finn.

Die Worte waren fest. Keine Frage. Eine Feststellung.

Allein kämpfen. Aber zusammen.

Das war der Unterschied.

Das war alles.

Er schaute in den Wind. In die Wolken. In die Leere.

Irgendwo dort war Theo. Gefangen. Allein. Wartend.

Finn hörte nichts. Keine Stimme. Kein Gefühl. Nur Wind.

Aber er wusste. Instinktiv. Wie man weiß, dass die Sonne aufgeht, auch wenn man sie nicht sieht.

Theo war da. Irgendwo. Und er wartete.

Nicht auf Rettung. Auf Finn.

Finn schloss die Augen. Ein Moment. Nur ein Moment.

Theos Gesicht. Vor seinem inneren Auge. Älter. Härter. Aber immer noch Theo. Immer noch sein Bruder.

"Bleib hier. Ich komme zurück."

Gelogen.

Aber diesmal würde Finn zurückkommen.

Oder er würde es versuchen.

"Wir gehen", sagte Finn.

Die Worte klangen anders. Nicht nach Flucht. Nicht nach Suche.

Nach Angriff.

Auf ein System, das sich unantastbar hielt.

Auf eine Stadt, die dachte, sie sei sicher.

Auf eine Welt, die vergessen hatte, dass auch die Kleinsten kämpfen konnten.

Finn öffnete die Augen.

Die Welt war noch da. Die Trümmer. Die Verletzten. Die zerstörte Stadt.

Aber sie war nicht mehr das Ende.

Sie war der Anfang.

Finn drehte sich um. Zu seinem Team. Zu seinen Freunden. Zu seiner Familie.

"Wir gehen nach Lumion", sagte er. "Und wir holen Theo zurück."

Rex grinste. Bitter. Hart.

"Oder wir sterben beim Versuch."

"Oder das", sagte Finn.

Nila rollte die Augen. Aber sie lächelte. Leicht. Fast unsichtbar.

"Idioten", murmelte sie.

"Deine Idioten", sagte Rex.

"Leider", sagte Nila.

Elara sagte nichts. Sie schaute nur. Auf Finn. Auf das Team. Auf die Zukunft, die vor ihnen lag.

Dann, langsam, ein Nicken.

"Gut", sagte sie. "Dann gehen wir."

Finn atmete. Tief. Einmal. Zweimal.

Die Hände zitterten nicht mehr.

Die Knie trugen ihn.

Die Stimmen in seinem Kopf waren still. Vorläufig. Aber still.

Er schaute in den Wind. In die Wolken. In die Leere.

Und diesmal hörte er etwas.

Nicht Theos Stimme. Nicht Verdantis' Gefühl.

Nur einen Druck. Ein Gefühl. Eine Gewissheit.

*Zeit.*

Es war Zeit.

Zeit zu kämpfen.

Zeit zu gewinnen.

Oder zu verlieren.

Aber auf jeden Fall: Zeit zu handeln.

Finn wandte sich ab. Von den Trümmern. Von der zerstörten Stadt. Von der Vergangenheit.

Er ging. Langsam. Aber fest.

Sein Team folgte.

Rex zuerst. Seine Schritte waren hart. Bestimmt. Embrix auf seiner Schulter. Der Salamander zuckte. Unruhig. Aber bereit.

Nila daneben. Ihre Hände waren zu Fäusten geballt. Aquor an ihrer Seite. Der Otter winselte nicht mehr. Stand. Fest. Wie eine Mauer.

Elara als letzte. Langsam. Bedacht. Terragus neben ihr. Der Steinwesen bewegte sich nicht. Stand. Wie ein Fels. Unbeweglich. Unerschütterlich.

Hinter ihnen: Die Wandernde Stadt. Zerstört. Aber nicht besiegt.

Vor ihnen: Lumion. Die Hauptstadt. Das Herz des Systems.

Und irgendwo dazwischen: Theo.

Wartend.

Auf sie.

Finns Schritt wurde fester. Schneller.

Die Hände zitterten nicht mehr.

Die Knie trugen ihn.

Die Stimmen in seinem Kopf waren still. Vorläufig. Aber still.

Er schaute in den Wind. In die Wolken. In die Leere.

Und diesmal hörte er etwas.

Nicht Theos Stimme. Nicht Verdantis' Gefühl.

Nur einen Druck. Ein Gefühl. Eine Gewissheit.

*Zeit.*

Es war Zeit.

Zeit zu kämpfen.

Zeit zu gewinnen.

Oder zu verlieren.

Aber auf jeden Fall: Zeit zu handeln.

Die Reise begann.

Die letzte Reise.

Die wichtigste Reise.

Und diesmal würde Finn nicht allein gehen.

Diesmal hatte er sein Team.

Seine Familie.

Seine Freunde.

Und das war genug.

Mehr als genug.

---

**ENDE KAPITEL 19**

**NÄCHSTES: KAPITEL 20 – DIE HAUPTSTADT (Lumion-Ankunft → Überwältigung/Propaganda → Widerstandskontakt → "Theo ist schon im Palast" / Exekutions-Countdown)**

