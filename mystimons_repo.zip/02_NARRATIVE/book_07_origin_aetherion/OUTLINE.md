# BOOK 07 ORIGIN AETHERION

**Status:** Scaffold

**Ziel:** Origin/Prequel – Entstehung von Aetherion (Release #7 nach Band 6).

## Leitplanken
- Spoiler-Gate: volle Fakten nur hier.
- Keine Retcons gegen Canon Laws; nur Reframing von zuvor als Mythos geführten Informationen.

## Struktur
- Akt I: Setup (Vor-Aetheria)
- Akt II: Catalyst
- Akt III: Entstehung/Preis
- Epilog: Brücke zur Hauptreihe
