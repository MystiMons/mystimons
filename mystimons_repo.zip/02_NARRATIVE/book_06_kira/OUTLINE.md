# BOOK 06 KIRA

**Status:** Scaffold

## Protagonistin
- Kira

## Kernziele
- Konsequenzen aus Band 4 weiterführen
- Eskalation/Reveal in Richtung Band 6 Finale

## Outline (Platzhalter)
- TBD
