# Book 02 – Outline (WIP)

- Protagonist: Finn
- Canon: Follow 00_CANON/SINGLE_SOURCE_OF_TRUTH.md

## Act Structure
- Act I:
- Act II:
- Act III:

## Key Events
- 
