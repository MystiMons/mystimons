| id | name | card_type | rarity | cost | stats | print_text | tracking | rng | patchable | tags | notes |
|---|---|---|---|---|---|---|---|---|---|---|---|
